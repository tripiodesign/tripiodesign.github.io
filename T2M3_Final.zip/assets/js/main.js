$('#thPartido').addClass('text-warning');
$('#thRepresent').addClass('text-warning');
$('#thPctVotos').addClass('text-warning');

$('#ttMas1').addClass('text-warning');
$('#ttMas2').addClass('text-warning');
$('#ttMas3').addClass('text-warning');

$('#ttMenos1').addClass('text-warning');
$('#ttMenos2').addClass('text-warning');
$('#ttMenos3').addClass('text-warning');

$('#ttMasL1').addClass('text-warning');
$('#ttMasL2').addClass('text-warning');
$('#ttMasL3').addClass('text-warning');

$('#ttMenosL1').addClass('text-warning');
$('#ttMenosL2').addClass('text-warning');
$('#ttMenosL3').addClass('text-warning');
